﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureMIDTERM
{
    public class Inventory
    {

        private List<string> items;

        public Inventory()
        {
            items = new List<string>();

        }

        public void AddItem(string item)
        {
            items.Add(item);
            Console.WriteLine($"Added {item} to the inventory.");
        }

        public void CheckInventory()
        {
            Console.WriteLine("Here's your inventory");
            foreach (string item in items)
            {
                Console.WriteLine(item);
            }
        }
    }
}
