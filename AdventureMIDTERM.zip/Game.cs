﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureMIDTERM
{
    public class Game
    {
    
        
        
        bool continueGame = true;

        string playerLocation; //Trackss player location

        int playerStamina = 100;



        public void MenuScreen()
        {
            Console.WriteLine("Welcome to the Cash Money City!");
            Console.WriteLine("Please enter your name ");

            string playerName = Console.ReadLine();
            Console.WriteLine($"Welcome {playerName}!");

            Console.ReadLine();

            Console.Clear();

            Console.WriteLine("Options:");
            Console.WriteLine("1. Explore the city");
            Console.WriteLine("2. Check your inventory");
            Console.WriteLine("3. Exit");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.WriteLine("Welcome to the Cash Money City! You explore the city!");
                    break;
                case "2":
                    Console.WriteLine("You check your inventory.");
                    break;
                case "3":
                    Console.WriteLine("Thank you for playing! Exiting the adventure.");
                    continueGame = false;
                    Environment.Exit(0);

                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter a number between 1 and 3.");
                    break;

                    
                     

            }

           
        }
        public void ExploreDialogue()
        {
            Console.WriteLine("Where would you like to go?");

            Console.WriteLine("1. Explore the Tallest Tower.");
            Console.WriteLine("2. Explore the city's sewers.");
            Console.WriteLine("3. Explore the abandoned restaraunt.");
            Console.WriteLine("4. Explore the Candy Store.");
            if (playerStamina >= 20)
            {
                // Player has enough stamina to explore
                Console.WriteLine("You set out to explore the city.");

                // Deduct stamina for exploration
                playerStamina -= 20;

                // Perform exploration logic...
            }
            else
            {
                // Player doesn't have enough stamina to explore
                Console.WriteLine("You are too tired to explore further. Please rest and try again later.");
            }



            string explore = Console.ReadLine();
            

            switch (explore)
            {

                case "1":

                    playerLocation = "Tallest Tower";
                    Console.WriteLine("You are now at the Tallest Tower.");
                    playerStamina -= 5;

                    Console.WriteLine("You walk through the double doors. You see something shiny in a corner.");
                    Console.WriteLine("Do you wish to pick it up? Type Yes or No.");

                    string input = Console.ReadLine();

                    if (input == "yes") 
                    {
                        Inventory inventory = new Inventory();
                        PocketWatch pocketWatch = new PocketWatch();


                        inventory.AddItem("Gold Pocket Watch");

                        Console.WriteLine("You've found a pocket watch!");
                        pocketWatch.DisplayTime();

                        Console.WriteLine("There was nothing else valuable inside the building so you leave.");

                        Console.ReadLine();

                        ExploreDialogue();
                        

                    }

                    else if (input == "no")
                    {
                        Console.WriteLine("You from reason are too afraid to explore the shiny object.");
                        Console.WriteLine("You leave.");
                        Console.ReadLine();
                        Console.Clear();

                        
                        ExploreDialogue();
                    }

                    break;
                case "2":

                    playerLocation = "City Sewers";
                    Console.WriteLine("You are now in the City Sewers.");

                    Console.WriteLine("You go in the sewers.");
                    Console.WriteLine("You've been exploring for five minutes and find a damaged toy car. Do you want to acquire it?");
                    input = Console.ReadLine();

                    if (input == "yes")
                    {
                        Inventory inventory = new Inventory();
                        Toy toy= new Toy();
                        inventory.AddItem("Toy Car");
                        Console.WriteLine("You picked up the toy car!");
                        
                        toy.ToyActivate();
                        Console.ReadLine();

                        ExploreDialogue();

                    }

                    else if (input == "no")
                    {
                        Console.WriteLine("It's just a toy but okay.");
                        Console.ReadLine();
                        Console.Clear();


                        ExploreDialogue();
                    }
                    break;
                case "3":

                    playerLocation = "Abandoned Restaurant";
                    Console.WriteLine("You are now at the Abandoned Restaurant.");

                    Console.WriteLine("You walk into the abandonded restaurant.");
                    Console.WriteLine("You snoop around for a while and you find some strange looking device.");
                    Console.ReadLine();
                    Console.Clear();

                    Console.WriteLine("Do you want to find out what this device is? Type Yes or No.");
                    input = Console.ReadLine();

                    if (input == "yes")
                    {
                        Radio radio = new Radio();

                        Console.WriteLine("you go to pick the item up and you realize its a Walkie Talkie!");
                        Console.ReadLine();
                        Console.Clear();

                        Console.WriteLine("The radio turns on!");
                        radio.UseRadio();

                        ExploreDialogue();

                    }

                    else if (input == "no")
                    {
                        Console.WriteLine("You decided to not find out. You walk back outside because not much else was valuable.");
                        Console.ReadLine();
                        Console.Clear();


                        ExploreDialogue();
                    }
                    break;

                    case "4":

                    playerLocation = "Candy Store";
                    Console.WriteLine("You are now at the Candy Store.");

                    Console.WriteLine("You walk into the Candy Store.");
                    Console.WriteLine("What would you like to do?");
                    Console.WriteLine("1. Buy Candy");
                    Console.WriteLine("2. Explore");
                    Console.WriteLine("3. Leave");
                     input = Console.ReadLine();
                    Candy candy = new Candy();
                    
                    if (input == "1")
                    {
                        candy.BuyCandy();
                        Console.ReadLine();
                        Console.Clear();

                        Console.WriteLine("There is still more to do!");
                        Console.WriteLine("Would you like to explore?");

                        if (input == "yes")
                        {
                            candy.ExploreStore();
                        }

                        else if (input == "no")
                        {
                            ExploreDialogue();
                        }
                    }



                    Console.ReadLine();
                    Console.Clear();

                    ExploreDialogue();
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter a number between 1 and 3.");
                    break;

                  
                    
            }

            switch (playerLocation)
            {
                case "Tallest Tower":
                    // Logic for exploring the tallest tower
                    break;
                case "City Sewers":
                    // Logic for exploring the city sewers
                    break;
                case "Abandoned Restaurant":
                    // Logic for exploring the abandoned restaurant
                    break;
                case "Candy Store":
                    // Logic for exploring the candy store
                    break;
            }


        }
        

           
    }

}
