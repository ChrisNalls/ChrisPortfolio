﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureMIDTERM
{
    public class Candy
    {

        public void BuyCandy()
        {
            Console.WriteLine("You walk to the candy section and pick your favorite candies.");
            Console.WriteLine("Enjoy your candies!");
        }

        public void ExploreStore()
        {
            Console.WriteLine("You start exploring the store...");
            Console.WriteLine("You find a hidden door behind the shelves.");
            Console.WriteLine("Do you want to open the door? Type Yes or No.");
            string input = Console.ReadLine();

            if (input.ToLower() == "yes")
            {
                Console.WriteLine("You open the door and find a secret candy laboratory!");
                Console.WriteLine("You taste some experimental candies.");
                Console.WriteLine("It's a unique experience!");
            }
            else
            {
                Console.WriteLine("You decide not to open the door.");
                Console.WriteLine("You continue exploring the store.");
            }
        }
    }
    
}