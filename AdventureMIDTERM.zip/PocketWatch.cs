﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureMIDTERM
{
    public class PocketWatch
    {

        public void DisplayTime()
        {

            Console.WriteLine("The time is: " + DateTime.Now.ToString("hh:mm:ss tt"));
            Console.ReadLine();
        }
    }
}
