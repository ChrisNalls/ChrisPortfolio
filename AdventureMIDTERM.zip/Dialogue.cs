﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AdventureMIDTERM
{
    public class Dialogue
    {

        public string[] dialogue = { "Welcome to Cash Money City ", "Check your pocket to see your acquired items!", "Exit the city." };

    }
}
