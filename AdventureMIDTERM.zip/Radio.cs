﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventureMIDTERM
{
    public class Radio
    {
        private const int MaxBatteryLife = 1; 
        public void UseRadio()
        {

            Console.WriteLine("Stranger: HELLO? HELLO? IS ANYONE THERE?");

            Console.WriteLine("The frequency turns staticky");

            Console.WriteLine("Battery Life:" + MaxBatteryLife);
        }


    }
}
